import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Clipboard from 'expo-clipboard';

export default function DonateScreen() {
  const [copied, setCopied] = useState(false);
  const walletAddress = 'UQARJUg2Ewvs60wvRCXkLjqMPN24AjUpJtitjR8R9VQ_E80p';
  const donationAmount = 0.1;

  const copyToClipboard = async () => {
    await Clipboard.setStringAsync(walletAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <LinearGradient
      colors={['#0a0a2e', '#1a1a4f']}
      style={styles.container}
    >
      <View style={styles.content}>
        <View style={styles.iconContainer}>
          <Ionicons name="diamond" size={64} color="#00ffff" />
        </View>
        
        <Text style={styles.title}>Support the Game</Text>
        <Text style={styles.description}>
          Donate {donationAmount} TON to unlock boosters and support development!
        </Text>

        <Pressable
          onPress={copyToClipboard}
          style={({ pressed }) => [
            styles.walletCard,
            pressed && styles.walletCardPressed
          ]}
        >
          <LinearGradient
            colors={['#2d2d5d', '#1f1f4f']}
            style={styles.walletGradient}
          >
            <Text style={styles.walletLabel}>TON Wallet Address:</Text>
            <Text style={styles.walletAddress}>{walletAddress}</Text>
            <View style={styles.copyButton}>
              <Ionicons
                name={copied ? "checkmark" : "copy"}
                size={24}
                color={copied ? "#4CAF50" : "#00ffff"}
              />
            </View>
          </LinearGradient>
        </Pressable>

        <Text style={styles.rewardNote}>
          * After donation, boosters will be unlocked automatically
        </Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#1a1a4f',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 12,
    textAlign: 'center',
  },
  description: {
    fontSize: 16,
    color: '#888',
    textAlign: 'center',
    marginBottom: 32,
  },
  walletCard: {
    width: '100%',
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 5,
    shadowColor: '#00ffff',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  walletGradient: {
    padding: 16,
  },
  walletCardPressed: {
    transform: [{ scale: 0.98 }],
  },
  walletLabel: {
    fontSize: 14,
    color: '#888',
    marginBottom: 8,
  },
  walletAddress: {
    fontSize: 16,
    color: '#00ffff',
    marginBottom: 8,
  },
  copyButton: {
    position: 'absolute',
    right: 16,
    top: '50%',
    transform: [{ translateY: -12 }],
  },
  rewardNote: {
    marginTop: 24,
    fontSize: 14,
    color: '#888',
    textAlign: 'center',
    fontStyle: 'italic',
  },
});